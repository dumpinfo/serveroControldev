package com.zltech.ty;

import java.util.HashMap;
import java.util.LinkedHashMap;

import javax.security.auth.PrivateCredentialPermission;

import org.json.JSONException;
import org.json.JSONObject;

import android.R.bool;
import android.R.integer;
import android.R.string;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract.CommonDataKinds.Event;
import android.text.StaticLayout;
import android.text.TextUtils.TruncateAt;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager.LayoutParams;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.iflytek.cloud.ErrorCode;
import com.iflytek.cloud.InitListener;
import com.iflytek.cloud.RecognizerListener;
import com.iflytek.cloud.RecognizerResult;
import com.iflytek.cloud.SpeechConstant;
import com.iflytek.cloud.SpeechError;
import com.iflytek.cloud.SpeechRecognizer;
import com.iflytek.cloud.SpeechUtility;
import com.iflytek.cloud.ui.RecognizerDialog;
import com.iflytek.cloud.ui.RecognizerDialogListener;
import com.iflytek.cloud.util.ContactManager.ContactListener;
import com.iflytek.speech.util.JsonParser;
import com.zltech.ty.BluetoothService;
import com.zltech.ty.DeviceListActivity;
import com.zltech.ty.VerticalSeekBar;



@SuppressLint("DefaultLocale")
public class MainActivityTY extends Activity {
		
	//重力感应
	private SensorManager mManager = null;
	private Sensor mSensor = null;
	private SensorEventListener mListener = null;
	private boolean smFlag = false;
	private float x,y,z;
	private String strZL = "";
	private ToggleButton btn_zl;
	
	//蓝牙相关
	private static BluetoothAdapter btAdapter = null;
	private static BluetoothDevice btDevice = null;
	private static BluetoothService btService = null;
	String message, inputMsgString="";
	byte[] outMsgBuffer, inputMsgBuffer;
	int msgLength, inputMsgLen = 0;
    private static String remoteDeviceAddress, remoteDeviceName;
    private Button btn_bt;
    
    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE = 1;
    private static final int REQUEST_ENABLE_BT = 2;
    private static final int REQUEST_INPUT_MSG = 3;
    
    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";    
    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;
    // Constants that indicate the current connection state
    public static final int STATE_NONE = 0;       // we're doing nothing
    public static final int STATE_LISTEN = 1;     // now listening for incoming connections
    public static final int STATE_CONNECTING = 2; // now initiating an outgoing connection
    public static final int STATE_CONNECTED = 3;  // now connected to a remote device
    private int btState = STATE_NONE;
    
    String[] cmd_name_default= {
	         "未定义","未定义","未定义","未定义",
	         "未定义","未定义","未定义","未定义",
	         "未定义","未定义","未定义","未定义",
	         "未定义","未定义","未定义","未定义",
	         "未定义","未定义","未定义","未定义",
	         "前进","后退","左转","右转",
	         "停止","复位",
    };
    
    String[] cmd_push_default= {
	         "$1!","$2!","$3!","$4!",
	         "$5!","$6!","$7!","$8!",
	         "$9!","$a!","$b!","$c!",
	         "$d!","$e!","$f!","$g!",
	         "$h!","$i!","$j!","$k!",
	         "$l!","$m!","$n!","$o!",
	         "$p!","$q!",
   };
    
    String[] cmd_pop_default= {
    		 "$1!","$2!","$3!","$4!",
	         "$5!","$6!","$7!","$8!",
	         "$9!","$a!","$b!","$c!",
	         "$d!","$e!","$f!","$g!",
	         "$h!","$i!","$j!","$k!",
	         "$l!","$m!","$n!","$o!",
	         "$p!","$q!",
   };
    
    
    //控制中心
    private static final String CONFIG_FILE = "config_file";
    String[] cmd_name;
    String[] cmd_push;
    String[] cmd_pop;
    int mode = 0;
    
    TextView txtTest;
    Button btnMic;
    boolean flag_btnMic = false;
    Button[] btnDZ;
    int ZDY_NUM = 26;
    
    Button btn_config;
    TextView txtIndex;
    EditText edtZDLName, edtZDYPush, edtZDYPop;
    Button btnZDYBack, btnZDYNext, btnZDYOk;
    Dialog configDialog;
    private int temp;
    String micGetStr;
    boolean micGetStrFlag =false;
    long micGetStrValue;
    
    //定时器相关
    private Handler myHandler=null;
    private Runnable myRunnable=null;
    private static final int HANDLER_TIME = 3000;
    public static final String PREFER_NAME = "com.iflytek.setting";
    private static String TAG = "car";
    private static String TAG1 = "action";
	// 语音听写对象
	private SpeechRecognizer mIat;
	// 语音听写UI
	private RecognizerDialog mIatDialog;
	// 用HashMap存储听写结果
	private HashMap<String, String> mIatResults = new LinkedHashMap<String, String>();

	private EditText mResultText;
	private Toast mToast;
	private SharedPreferences mSharedPreferences;
	// 引擎类型
	private String mEngineType = SpeechConstant.TYPE_CLOUD;
	// 语记安装助手类
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.main_layout);
				
		//////////////////////////////////////////////////////
		txtTest = (TextView)findViewById(R.id.txtTest);
		
		
		////////////////////////////////////////////////////////////
		SpeechUtility.createUtility(getBaseContext(), SpeechConstant.APPID +"=562d98d7");   
		// 使用SpeechRecognizer对象，可根据回调消息自定义界面；
		mIat = SpeechRecognizer.createRecognizer(MainActivityTY.this, mInitListener);
		
		// 初始化听写Dialog，如果只使用有UI听写功能，无需创建SpeechRecognizer
		// 使用UI听写功能，请根据sdk文件目录下的notice.txt,放置布局文件和图片资源
		mIatDialog = new RecognizerDialog(MainActivityTY.this, mInitListener);

		mSharedPreferences = getSharedPreferences(PREFER_NAME,Activity.MODE_PRIVATE);
		mToast = (Toast)Toast.makeText(this, "", Toast.LENGTH_SHORT);
		mEngineType = SpeechConstant.TYPE_CLOUD;
		
		////////////////////////////////////////////////////////////
		//重力感应设置
		mManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
		mSensor = mManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);	
		mListener = new SensorEventListener() {
			@Override
			public void onSensorChanged(SensorEvent event) {
				// TODO Auto-generated method stub
				if(smFlag) {
					x = event.values[SensorManager.DATA_X];
					y = event.values[SensorManager.DATA_Y];
					z = event.values[SensorManager.DATA_Z];
					//扩大十倍
					strZL = "X:" + ((Integer)((int)(x*10))).toString()
						+ "  Y:" + ((Integer)((int)(y*10))).toString()
						+ "  Z:" + ((Integer)((int)(z*10))).toString();
					//TODO CMD
					strZL.replace("  ", "");
					strZL.replace(":", "");
					sendCmd("ZL" + "-" + "X" + ((Integer)((int)(x*10))).toString()
							+ "Y" + ((Integer)((int)(y*10))).toString()
							+ "Z" + ((Integer)((int)(z*10))).toString());
				}
			}
			@Override
			public void onAccuracyChanged(Sensor sensor, int accuracy) {
				// TODO Auto-generated method stub
				
			}
		};
		////////////////////////////////////////////////////////////

		init_var();
		init_config_file(CONFIG_FILE);
		read_config(CONFIG_FILE);
		handle_btns();
		btnDZ_event();
		
		////////////////////////////////////////////////////////////
		//btn_zl = (Button)findViewById(R.id.btn_zl);
		/*btn_zl.setText("");
		btn_zl.setChecked(false);
		btn_zl.setBackgroundResource(R.drawable.zl_off);
		btn_zl.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				// TODO Auto-generated method stub
				if(btn_zl.isChecked()) {
					btn_zl.setBackgroundResource(R.drawable.zl_on);
					smFlag = true;
					mManager.registerListener(mListener, mSensor, SensorManager.SENSOR_DELAY_GAME);
					//打开传感器
					if(btState == STATE_CONNECTED) {
						sendCmd("[UART2:O]");
						sendCmd("[UART2:O]");
						sendCmd("[UART2:O]");
						txtTest.setText("传感器已打开~");
					} else {
						DisplayToast("请先连接设备~");
						btn_zl.setBackgroundResource(R.drawable.zl_off);
					}
					
				} else {
					btn_zl.setBackgroundResource(R.drawable.zl_off);
					smFlag = false;
					mManager.unregisterListener(mListener);
					//关闭传感器
					if(btState == STATE_CONNECTED) {
						sendCmd("[UART2:F]");
						sendCmd("[UART2:F]");
						sendCmd("[UART2:F]");
						txtTest.setText("传感器已关闭~");
					} else {
						DisplayToast("请先连接设备~");
					}
					
				}
			}
		});*/
		
		////////////////////////////////////////////////////////////
		//蓝牙初始化
		btAdapter = BluetoothAdapter.getDefaultAdapter();
		btn_bt = (Button)findViewById(R.id.btn_bt);
		btn_bt.setBackgroundResource(R.drawable.bt_off);
		//btn_bt.setBackgroundDrawable(R.drawable.)
		btn_bt.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(btAdapter.getState() == BluetoothAdapter.STATE_OFF) {
					btAdapter.enable(); 
	        	} 

				if(btAdapter.getState() == BluetoothAdapter.STATE_ON) {
		            Intent serverIntent = new Intent(MainActivityTY.this, DeviceListActivity.class);
		            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
				}
			}
		});
		
		////////////////////////////////////////////////////////////
	    //语音
	    btnMic = (Button)findViewById(R.id.btn_mic);
	    //btnMic.setOnTouchListener(btnlListener);
	    
	    btnMic.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				{
					mIatResults.clear();
					// 设置参数
					setParam();
					boolean isShowDialog = mSharedPreferences.getBoolean(
							"record", true);
					if (isShowDialog) {
						// 显示听写对话框
						mIatDialog.setListener(mRecognizerDialogListener);
						mIatDialog.show();
						showTip("record start");
					} else {
						// 不显示听写对话框
						int ret = mIat.startListening(mRecognizerListener);
						if (ret != ErrorCode.SUCCESS) {
							showTip("听写失败,错误码：" + ret);
						} else {
							showTip("record start");
						}
					}
				}
			//	else{
			//		showTip("蓝牙未连接，请连接蓝牙");
			//	}
			}
		});
	    
		////////////////////////////////////////////////////////////
		//启动一个定时器 定时处理一些数据
		myHandler = new Handler();
		myRunnable = new Runnable() {
			@Override
			public void run() {
				// TODO Auto-generated method stub
				//监控蓝牙是否打开								
				//
					
//				if(micGetStrFlag) {
//					
//					DisplayToast("mic:" + micGetStr);
//					micGetStrFlag = false;
//				}
				if(micGetStrFlag) {
					micGetStrFlag = false;
					//DisplayToast("mic:" + micGetStr);
					
					txtTest.setText("Mic:" + micGetStr);

					for(int i=0;i<ZDY_NUM;i++) {
						if(cmd_name[i].contains(micGetStr)) {
							sendCmd(cmd_push[i]);
							txtTest.setText(txtTest.getText().toString() + " Cmd:" + cmd_push[i]);
							//DisplayToast("cmd:" + cmd_push[i]);
							break;
						} 
					}
					
				}
				
				myHandler.postDelayed(this, HANDLER_TIME);
			}
		};
		myHandler.postDelayed(myRunnable, HANDLER_TIME);		
		//DisplayToast("onCreate");
	    //////////////////////////////////////////////////////////////
	}//end of onCreate
	
	
	/////////////////////////////////////////////////////////////////////
	
	void init_var() {
		
		cmd_name = new String[ZDY_NUM];
    	cmd_push = new String[ZDY_NUM];
    	cmd_pop = new String[ZDY_NUM];
	}
	
	void handle_btns() {
				
		btnDZ = new Button[ZDY_NUM];
		btnDZ[0] = (Button)findViewById(R.id.btnDZ0);
		btnDZ[1] = (Button)findViewById(R.id.btnDZ1);
		btnDZ[2] = (Button)findViewById(R.id.btnDZ2);
		btnDZ[3] = (Button)findViewById(R.id.btnDZ3);
		btnDZ[4] = (Button)findViewById(R.id.btnDZ4);
		btnDZ[5] = (Button)findViewById(R.id.btnDZ5);
		btnDZ[6] = (Button)findViewById(R.id.btnDZ6);
		btnDZ[7] = (Button)findViewById(R.id.btnDZ7);
		btnDZ[8] = (Button)findViewById(R.id.btnDZ8);
		btnDZ[9] = (Button)findViewById(R.id.btnDZ9);
		btnDZ[10] = (Button)findViewById(R.id.btnDZ10);
		btnDZ[11] = (Button)findViewById(R.id.btnDZ11);
		btnDZ[12] = (Button)findViewById(R.id.btnDZ12);
		btnDZ[13] = (Button)findViewById(R.id.btnDZ13);
		btnDZ[14] = (Button)findViewById(R.id.btnDZ14);
		btnDZ[15] = (Button)findViewById(R.id.btnDZ15);
		btnDZ[16] = (Button)findViewById(R.id.btnDZ16);
		btnDZ[17] = (Button)findViewById(R.id.btnDZ17);
		btnDZ[18] = (Button)findViewById(R.id.btnDZ18);
		btnDZ[19] = (Button)findViewById(R.id.btnDZ19);
		btnDZ[20] = (Button)findViewById(R.id.btnDZ20);
		btnDZ[21] = (Button)findViewById(R.id.btnDZ21);
		btnDZ[22] = (Button)findViewById(R.id.btnDZ22);
		btnDZ[23] = (Button)findViewById(R.id.btnDZ23);
		btnDZ[24] = (Button)findViewById(R.id.btnDZ24);
		btnDZ[25] = (Button)findViewById(R.id.btnDZ25);
		
		for(int i=0;i<ZDY_NUM-6;i++) {
			btnDZ[i].setText(cmd_name[i]);
		}
		
		btn_config = (Button)findViewById(R.id.btn_setting);
		
		btn_config.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				int action = event.getAction();
				switch (action) {
					case MotionEvent.ACTION_UP:
						//btn_config.setBackgroundResource(R.drawable.setting);
						btn_config_click(0, "", "");
					break;
					case MotionEvent.ACTION_DOWN:
						//btn_config.setBackgroundResource(R.color.backgroud);
					break;
				}
				
				return false;
			}
		});	
		
		for(int j=0;j<ZDY_NUM-6;j++) {
			if(cmd_name[j] == ""){
				cmd_name[j] = "自定义"+((Integer)j).toString();
				btnDZ[j].setText(cmd_name[j]);
			}
    	}

	    

		
	}
	
    private void btnDZ_event() {

		btnDZ[0].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
		            switch (event.getAction()) {
			            case MotionEvent.ACTION_DOWN:// 按下
			            	//DisplayToast(cmd_push[0]);
			            	sendCmd(cmd_push[0]);
			            	btnDZ[0].setBackgroundResource(R.color.backgroud);
			                break;
			            case MotionEvent.ACTION_UP:  // // 松开
			            	//DisplayToast(cmd_pop[0]);
			            	sendCmd(cmd_pop[0]);
			            	btnDZ[0].setBackgroundResource(R.drawable.btn_bg);
			            default:
			                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[1].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[1]);
		            	btnDZ[1].setBackgroundResource(R.color.backgroud);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[1]);
		            	btnDZ[1].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[2].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[2]);
		            	btnDZ[2].setBackgroundResource(R.color.backgroud2);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[2]);
		            	btnDZ[2].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[3].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[3]);
		            	btnDZ[3].setBackgroundResource(R.color.backgroud2);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[3]);
		            	btnDZ[3].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		

		btnDZ[4].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[4]);
		            	btnDZ[4].setBackgroundResource(R.color.backgroud2);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[4]);
		            	btnDZ[4].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[5].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[5]);
		            	btnDZ[5].setBackgroundResource(R.color.backgroud2);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[5]);
		            	btnDZ[5].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[6].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[6]);
		            	btnDZ[6].setBackgroundResource(R.color.backgroud);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[6]);
		            	btnDZ[6].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[7].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[7]);
		            	btnDZ[7].setBackgroundResource(R.color.backgroud);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[7]);
		            	btnDZ[7].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[8].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
		            switch (event.getAction()) {
			            case MotionEvent.ACTION_DOWN:// 按下
			            	//DisplayToast(cmd_push[8]);
			            	sendCmd(cmd_push[8]);
			            	btnDZ[8].setBackgroundResource(R.color.touming);
			                break;
			            case MotionEvent.ACTION_UP:  // // 松开
			            	//DisplayToast(cmd_pop[8]);
			            	sendCmd(cmd_pop[8]);
			            	btnDZ[8].setBackgroundResource(R.drawable.btn_bg);
			            default:
			                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[9].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[9]);
		            	btnDZ[9].setBackgroundResource(R.color.touming);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[9]);
		            	btnDZ[9].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[10].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[10]);
		            	btnDZ[10].setBackgroundResource(R.color.touming);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[10]);
		            	btnDZ[10].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[11].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[11]);
		            	btnDZ[11].setBackgroundResource(R.color.backgroud);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[11]);
		            	btnDZ[11].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[12].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[12]);
		            	btnDZ[12].setBackgroundResource(R.color.backgroud2);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[12]);
		            	btnDZ[12].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[13].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[13]);
		            	btnDZ[13].setBackgroundResource(R.color.backgroud2);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[13]);
		            	btnDZ[13].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		

		btnDZ[14].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[14]);
		            	btnDZ[14].setBackgroundResource(R.color.backgroud2);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[14]);
		            	btnDZ[14].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[15].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[15]);
		            	btnDZ[15].setBackgroundResource(R.color.backgroud2);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[15]);
		            	btnDZ[15].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[16].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[16]);
		            	btnDZ[16].setBackgroundResource(R.color.backgroud);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[16]);
		            	btnDZ[16].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[17].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[17]);
		            	btnDZ[17].setBackgroundResource(R.color.backgroud);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[17]);
		            	btnDZ[17].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[18].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
		            switch (event.getAction()) {
			            case MotionEvent.ACTION_DOWN:// 按下
			            	//DisplayToast(cmd_push[18]);
			            	sendCmd(cmd_push[18]);
			            	btnDZ[18].setBackgroundResource(R.color.touming);
			                break;
			            case MotionEvent.ACTION_UP:  // // 松开
			            	//DisplayToast(cmd_pop[18]);
			            	sendCmd(cmd_pop[18]);
			            	btnDZ[18].setBackgroundResource(R.drawable.btn_bg);
			            default:
			                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[19].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[19]);
		            	btnDZ[19].setBackgroundResource(R.color.touming);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[19]);
		            	btnDZ[19].setBackgroundResource(R.drawable.btn_bg);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		

		btnDZ[20].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[20]);
		            	btnDZ[20].setBackgroundResource(R.color.touming);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[20]);
		            	btnDZ[20].setBackgroundResource(R.drawable.run_up);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		
		
		
		btnDZ[21].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[21]);
		            	btnDZ[21].setBackgroundResource(R.color.touming);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[21]);
		            	btnDZ[21].setBackgroundResource(R.drawable.run_dn);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		

		btnDZ[22].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[22]);
		            	btnDZ[22].setBackgroundResource(R.color.touming);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[22]);
		            	btnDZ[22].setBackgroundResource(R.drawable.run_lt);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[23].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[23]);
		            	btnDZ[23].setBackgroundResource(R.color.touming);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[23]);
		            	btnDZ[23].setBackgroundResource(R.drawable.run_rt);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[24].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[24]);
		            	btnDZ[24].setBackgroundResource(R.color.touming);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[24]);
		            	btnDZ[24].setBackgroundResource(R.drawable.stop);
		            default:
		                break;
		            }
		            return false;
		        }
		});
		
		btnDZ[25].setOnTouchListener(new OnTouchListener(){
			   public boolean onTouch(View v, MotionEvent event) {
				   
		            switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	sendCmd(cmd_push[25]);
		            	btnDZ[25].setBackgroundResource(R.color.touming);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	sendCmd(cmd_pop[25]);
		            	btnDZ[25].setBackgroundResource(R.drawable.reset);
		            default:
		                break;
		            }
		            return false;
		        }
		});	
			
    }
 
	
	
	////////////////////////////////////////////////////////////////////////	
	@Override
    public void onStart() {
        super.onStart();
       
        if (btAdapter.isEnabled()) {
            if (btService == null) {
            	setUpBtServer();
            }
        }
        //DisplayToast("onStart");
    }

	
	@Override
	protected synchronized void onResume() {
		super.onResume();
		//注册重力传感器
		mManager.registerListener(mListener, mSensor, SensorManager.SENSOR_DELAY_GAME);
		//开启蓝牙服务
		if (btService != null) {
            // Only if the state is STATE_NONE, do we know that we haven't started already
            if (btService.getState() == BluetoothService.STATE_NONE) {
              // Start the Bluetooth chat services
            	btService.start();
            }
		} else {
			if (btAdapter.isEnabled()) {
	            if (btService == null) {
	            	setUpBtServer();
	            	if (btService.getState() == BluetoothService.STATE_NONE) {
	                    // Start the Bluetooth chat services
	                  	btService.start();
	                  }
	            }
	        }
		}
		//DisplayToast("onResume");
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		
		//注销重力传感器
		mManager.unregisterListener(mListener);
		//myHandler.removeCallbacks(myRunnable);
		//DisplayToast("onPause");
	}
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		if(btService != null){
			destroyBtServer();
		}
		btAdapter.disable();
		//DisplayToast("onDestroy");
		//super.onDestroy();
	}
	
	private void setUpBtServer() {
		if(btService == null){
			btService = new BluetoothService(this, btHandler);	
		}
	}
		
	private void destroyBtServer() {
		if(btService != null){
			btService.stop();
			btService = null;
		}
	}
	
	private final Handler btHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
            case MESSAGE_STATE_CHANGE:
                //if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                switch (msg.arg1) {
                case BluetoothService.STATE_CONNECTED:
                	//DisplayToast("已连接");
                	btState = STATE_CONNECTED;
                	//btn_bt.setText("已连接");
                	//btn_bt.setTextColor(Color.GREEN);
                	DisplayToast("蓝牙已连接");
                	txtTest.setText("");
                	btn_bt.setBackgroundResource(R.drawable.bt_on);
                	break;
                case BluetoothService.STATE_CONNECTING:
                	//DisplayToast("正在连接。。。");
                	txtTest.setText("正在连接...");
                	btState = STATE_CONNECTING;
                	//btn_bt.setText("正在连接...");
                	//btn_bt.setTextColor(Color.YELLOW);
                	//btn_bt.setBackgroundResource(R.drawable.bt_gon3);
                    break;
                case BluetoothService.STATE_LISTEN:
                case BluetoothService.STATE_NONE:
                	//DisplayToast("无连接");
                	txtTest.setText("");
                	btState = STATE_NONE;  
                	//btn_bt.setText("无连接");
                	//btn_bt.setTextColor(Color.RED);
                	btn_bt.setBackgroundResource(R.drawable.bt_off);
                    break;
                }
                break;
            case MESSAGE_WRITE:
                //byte[] writeBuf = (byte[]) msg.obj;
                // construct a string from the buffer
                //String writeMessage = new String(writeBuf);
                //mConversationArrayAdapter.add("Me:  " + writeMessage);
            	//EdtDownCmd.setHint("send success!");
            	
                break;
            case MESSAGE_READ:
                byte[] readBuf = (byte[]) msg.obj;
                // construct a string from the valid bytes in the buffer
                String readMessage = new String(readBuf, 0, msg.arg1);
                inputMsgString += readMessage;
            break;
            case MESSAGE_DEVICE_NAME:
                // save the connected device's name
                //Toast.makeText(getApplicationContext(), "Connected to "
                //              + remoteDeviceName, Toast.LENGTH_SHORT).show();
            break;
            case MESSAGE_TOAST:
                //Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST),
                //               Toast.LENGTH_SHORT).show();
                break;
            }
        }
    };
	
    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        //if(D) Log.d(TAG, "onActivityResult " + resultCode);
        switch (requestCode) {
        case REQUEST_CONNECT_DEVICE:
            // When DeviceListActivity returns with a device to connect
            if (resultCode == Activity.RESULT_OK) {
                // Get the device MAC address
            	
            	btAdapter.cancelDiscovery();
            	remoteDeviceName = intent.getExtras()
                                     .getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
            	
                // Get the BLuetoothDevice object
            	remoteDeviceAddress = remoteDeviceName.substring(remoteDeviceName.length() - 17);
            	remoteDeviceName = remoteDeviceName.substring(0, remoteDeviceName.length()-18);
            	btDevice = btAdapter.getRemoteDevice(remoteDeviceAddress);
            	
            	// Attempt to connect to the device
            	setUpBtServer();
            	btService.connect(btDevice);   
            }
            break;
        case REQUEST_ENABLE_BT:
            // When the request to enable Bluetooth returns
            if (resultCode == Activity.RESULT_OK) {
                //Bluetooth is now enabled, so set up a chat session
            	//setUpBtServer();
            	
            } else {
            }
            break;
            
	    case REQUEST_INPUT_MSG:
	    break;
        }//end of switch
        //DisplayToast("onActivityResult");
        
    }
    
    //公用接口
  	public void DisplayToast(String str){
      	Toast toast=Toast.makeText(this, str, Toast.LENGTH_LONG);
      	toast.setGravity(Gravity.TOP, 0, 50);
      	toast.show();
    }
		
	public void sendCmd(String str) {
		if(btState == STATE_CONNECTED) {
			outMsgBuffer = (str).getBytes();
			btService.write(outMsgBuffer);
		} else {
			//DisplayToast("蓝牙未连接！");
		}
	}
	
	/**
	 * 初始化监听器。
	 */
	private InitListener mInitListener = new InitListener() {

		@Override
		public void onInit(int code) {
			Log.d(TAG, "SpeechRecognizer init() code = " + code);
			if (code != ErrorCode.SUCCESS) {
				showTip("初始化失败，错误码：" + code);
			}
		}
	};
	/**
	 * 听写监听器。
	 */
	private RecognizerListener mRecognizerListener = new RecognizerListener() {

		@Override
		public void onBeginOfSpeech() {
			// 此回调表示：sdk内部录音机已经准备好了，用户可以开始语音输入
			showTip("开始说话");
		}

		@Override
		public void onError(SpeechError error) {
			// Tips：
			// 错误码：10118(您没有说话)，可能是录音机权限被禁，需要提示用户打开应用的录音权限。
			// 如果使用本地功能（语记）需要提示用户开启语记的录音权限。
			showTip(error.getPlainDescription(true));
		}

		@Override
		public void onEndOfSpeech() {
			// 此回调表示：检测到了语音的尾端点，已经进入识别过程，不再接受语音输入
			showTip("结束说话");
		}

		@Override
		public void onResult(RecognizerResult results, boolean isLast) {
			Log.d(TAG, results.getResultString());
			printResult(results);

			if (isLast) {
				// TODO 最后的结果
			}
		}

		@Override
		public void onVolumeChanged(int volume, byte[] data) {
			showTip("当前正在说话，音量大小：" + volume);
			Log.d(TAG, "返回音频数据："+data.length);
		}

		@Override
		public void onEvent(int eventType, int arg1, int arg2, Bundle obj) {
			// 以下代码用于获取与云端的会话id，当业务出错时将会话id提供给技术支持人员，可用于查询会话日志，定位出错原因
			// 若使用本地能力，会话id为null
			//	if (SpeechEvent.EVENT_SESSION_ID == eventType) {
			//		String sid = obj.getString(SpeechEvent.KEY_EVENT_SESSION_ID);
			//		Log.d(TAG, "session id =" + sid);
			//	}
		}
	};

	private void printResult(RecognizerResult results) {
		String text = JsonParser.parseIatResult(results.getResultString());
		String sn = null;
		// 读取json结果中的sn字段
		try {
			JSONObject resultJson = new JSONObject(results.getResultString());
			sn = resultJson.optString("sn");
		} catch (JSONException e) {
			e.printStackTrace();
		}

		mIatResults.put(sn, text);

		StringBuffer resultBuffer = new StringBuffer();
		for (String key : mIatResults.keySet()) {
			resultBuffer.append(mIatResults.get(key));
		}
		String temp;
		temp = resultBuffer.toString();
		micGetStr = temp.substring(0,temp.length()-1);
		micGetStrFlag = true;
		
		/*showTip(temp);
		if (temp.contains("左转"))
		{
			Log.d(TAG1, "接收到：左转");
			sendCmd("BLTD");
		}
		else if (temp.contains("右转"))
		{
			Log.d(TAG1, "接收到：右转");	
			sendCmd("BRTD");
		}
		else if (temp.contains("前进"))
		{
			Log.d(TAG1, "接收到：前进");	
			sendCmd("BUPD");
		}
		else if (temp.contains("后退"))
		{
			Log.d(TAG1, "接收到：后退");	
			sendCmd("BDND");
		}
		else if (temp.contains("停止"))
		{
			Log.d(TAG1, "停止");	
			sendCmd("BUPU");
		}
		else
		{	
			Log.d(TAG1, "错误口令");
		}*/
	}

	/**
	 * 听写UI监听器
	 */
	private RecognizerDialogListener mRecognizerDialogListener = new RecognizerDialogListener() {
		public void onResult(RecognizerResult results, boolean isLast) {
			printResult(results);
		}

		/**
		 * 识别回调错误.
		 */
		public void onError(SpeechError error) {
			showTip(error.getPlainDescription(true));
		}

	};


	private void showTip(final String str) {
		//mToast.setText(str);
		//mToast.show();
		txtTest.setText(str);
	}

	/**
	 * 参数设置
	 * 
	 * @param param
	 * @return
	 */
	public void setParam() {
		// 清空参数
		mIat.setParameter(SpeechConstant.PARAMS, null);

		// 设置听写引擎
		mIat.setParameter(SpeechConstant.ENGINE_TYPE, mEngineType);
		// 设置返回结果格式
		mIat.setParameter(SpeechConstant.RESULT_TYPE, "json");

		String lag = mSharedPreferences.getString("iat_language_preference",
				"mandarin");
		if (lag.equals("en_us")) {
			// 设置语言
			mIat.setParameter(SpeechConstant.LANGUAGE, "en_us");
		} else {
			// 设置语言
			mIat.setParameter(SpeechConstant.LANGUAGE, "zh_cn");
			// 设置语言区域
			mIat.setParameter(SpeechConstant.ACCENT, lag);
		}

		// 设置语音前端点:静音超时时间，即用户多长时间不说话则当做超时处理
		mIat.setParameter(SpeechConstant.VAD_BOS, mSharedPreferences.getString("iat_vadbos_preference", "4000"));
		
		// 设置语音后端点:后端点静音检测时间，即用户停止说话多长时间内即认为不再输入， 自动停止录音
		mIat.setParameter(SpeechConstant.VAD_EOS, mSharedPreferences.getString("iat_vadeos_preference", "1000"));
		
		// 设置标点符号,设置为"0"返回结果无标点,设置为"1"返回结果有标点
		mIat.setParameter(SpeechConstant.ASR_PTT, mSharedPreferences.getString("iat_punc_preference", "1"));
		
		// 设置音频保存路径，保存音频格式支持pcm、wav，设置路径为sd卡请注意WRITE_EXTERNAL_STORAGE权限
		// 注：AUDIO_FORMAT参数语记需要更新版本才能生效
		mIat.setParameter(SpeechConstant.AUDIO_FORMAT,"wav");
		mIat.setParameter(SpeechConstant.ASR_AUDIO_PATH, Environment.getExternalStorageDirectory()+"/msc/iat.wav");
	}
	
	
	
	private void init_config_file(String filename) {
		SharedPreferences file;  
	    SharedPreferences.Editor editor; 

	    //获得配置文件  
        file = getSharedPreferences(filename,  Context.MODE_PRIVATE); 
        editor = file.edit();  
        
        if(!file.contains("remoteDeviceName")) {
        	editor.putString("remoteDeviceName", "");
        }
        
        if(!file.contains("remoteDeviceName")) {
        	editor.putString("remoteDeviceAddress", "");
        }
        
        int index = 0;
	        for(index = 0; index<ZDY_NUM; index++) {
	        	if(!file.contains("cmd_name" +((Integer)index).toString() )) {
	        		cmd_name[index] = cmd_name_default[index];
	            	editor.putString("cmd_name" + ((Integer)index).toString(), cmd_name[index]);
	            }
	        	
	        	if(!file.contains("cmd_push" + ((Integer)index).toString())) {
	        		cmd_push[index] = cmd_push_default[index] ;
	        		editor.putString("cmd_push" + ((Integer)index).toString(), cmd_push[index]);
	            }
	        	
	        	if(!file.contains("cmd_pop" + ((Integer)index).toString() )) {
	        		cmd_pop[index] = cmd_pop_default[index] ;
	        		editor.putString("cmd_pop" +((Integer)index).toString(), cmd_pop[index]);
	            }
	        	
        }
              
        editor.commit();  		
	}
	
	private void read_config(String filename) {
		SharedPreferences file = null;  
		//获得配置文件  
        file = getSharedPreferences(filename,  Context.MODE_PRIVATE); 
        remoteDeviceName = file.getString("remoteDeviceName", null);
        remoteDeviceAddress = file.getString("remoteDeviceAddress", null);
        int index = 0;
        for(index = 0; index<ZDY_NUM; index++) {
        	cmd_name[index] = file.getString("cmd_name" + ((Integer)index).toString(), null);
        	cmd_push[index] = file.getString("cmd_push" +   ((Integer)index).toString(), null);
        	cmd_pop[index]  = file.getString("cmd_pop"  +  ((Integer)index).toString(), null); 
        }
        
	}
	
	private void write_file(String filename, String key, String value) {
		SharedPreferences file;  
	    SharedPreferences.Editor editor; 
	    //获得配置文件  
        file = getSharedPreferences(filename,  Context.MODE_PRIVATE); 
        editor = file.edit();  
        editor.putString(key, value);
        editor.commit();  
	}
	
	private String read_file(String filename, String key) {
		SharedPreferences file = null;  
	    //获得配置文件  
        file = getSharedPreferences(filename,  Context.MODE_PRIVATE); 
        return file.getString(key, null);
	}
	
private void btn_config_click(int index, String btnStr, String btnCmd) {
		
		LayoutInflater factory = LayoutInflater.from(this);//这里建立一个工厂，产出view用的。需要传入activity的实例对象。大概就是工厂工人的作用吧。
		final View loginView = factory.inflate(R.layout.config, null);
		
		WindowManager m = getWindowManager();   
		Display d = m.getDefaultDisplay();
		LayoutParams p = getWindow().getAttributes();  	//获取对话框当前的参数值 
		p.height = (int) (d.getHeight() * 0.95);   		//高度设置为屏幕的0.95 
		p.width = (int) (d.getWidth() * 0.95);    		//宽度设置为屏幕的0.95 
		
		txtIndex = (TextView) loginView.findViewById(R.id.txtIndex);
		edtZDLName = (EditText) loginView.findViewById(R.id.edtZDLName);
    	edtZDYPush = (EditText) loginView.findViewById(R.id.edtZDYPush);
    	edtZDYPop = (EditText) loginView.findViewById(R.id.edtZDYPop);
    	btnZDYBack = (Button) loginView.findViewById(R.id.btnZDYBack); 
    	btnZDYNext = (Button) loginView.findViewById(R.id.btnZDYNext); 
    	btnZDYOk = (Button) loginView.findViewById(R.id.btnZDYOk); 

		//这个easy了，就是生成个view。用了个inflate的函数，英译过来就是填充，都懂得。
		AlertDialog.Builder loginDialog = new AlertDialog.Builder(this);			
		//这个就是搞个dialog出来，当然这个东西里面什么都没有，还在建设中。。
		loginDialog.setView(loginView);//现在ok了，里面有东西了。建设一点了。
		loginListen pl = new loginListen(loginView, index, btnStr, btnCmd);//这里可能有点疑惑，等会再说。
		//loginDialog.setTitle("命令配置").setPositiveButton("确定", pl).setNegativeButton("取消", pl);
		configDialog = loginDialog.create();//ok这里建设好了，所以create一下，就生成dialog了。接着show，就出来dialog了
		configDialog.show();
		configDialog.getWindow().setLayout(p.width, p.height);
		
    	    
	}//end of btn_config_click
    
   private class loginListen implements DialogInterface.OnClickListener {	    
	    
	    public loginListen(View in, int index,  String btnStr, String btnCmd ) {
	    	
	    	txtIndex.setText("0");
	    	edtZDLName.setText(cmd_name[0]);
			edtZDYPush.setText(cmd_push[0]);
			edtZDYPop.setText(cmd_pop[0]);
			
			btnZDYBack.setOnTouchListener(new OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	btnZDYBack.setBackgroundResource(R.color.backgroud);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	btnZDYBack.setBackgroundResource(R.drawable.cb4_on);
						temp = Integer.parseInt(txtIndex.getText().toString());	
						cmd_name[temp] = edtZDLName.getText().toString();
						cmd_push[temp] = edtZDYPush.getText().toString();
						cmd_pop[temp] = edtZDYPop.getText().toString();
						if(temp<ZDY_NUM-6)btnDZ[temp].setText(cmd_name[temp]);
						
						if(temp<ZDY_NUM-6)write_file(CONFIG_FILE, "cmd_name" + ((Integer)temp).toString(), cmd_name[temp]);
				    	write_file(CONFIG_FILE, "cmd_push"  + ((Integer)temp).toString(), cmd_push[temp]);
				    	write_file(CONFIG_FILE, "cmd_pop" + ((Integer)temp).toString(), cmd_pop[temp]);
						
						if(temp == 0) {
							temp = ZDY_NUM-1;
						} else temp--;
						txtIndex.setText(((Integer)temp).toString());
						
						edtZDLName.setText(cmd_name[temp]);
						edtZDYPush.setText(cmd_push[temp]);
						edtZDYPop.setText(cmd_pop[temp]);
		            default:
		                break;
		            }
		            return false;
				}
			});
			
			btnZDYNext.setOnTouchListener(new OnTouchListener() {
				
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	btnZDYNext.setBackgroundResource(R.color.backgroud);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	btnZDYNext.setBackgroundResource(R.drawable.cb4_on);
						temp = Integer.parseInt(txtIndex.getText().toString());	
						if(temp<ZDY_NUM-6)cmd_name[temp] = edtZDLName.getText().toString();
						cmd_push[temp] = edtZDYPush.getText().toString();
						cmd_pop[temp] = edtZDYPop.getText().toString();
						if(temp<ZDY_NUM-6)btnDZ[temp].setText(cmd_name[temp]);
	
						write_file(CONFIG_FILE, "cmd_name" + ((Integer)temp).toString(), cmd_name[temp]);
				    	write_file(CONFIG_FILE, "cmd_push" + ((Integer)temp).toString(), cmd_push[temp]);
				    	write_file(CONFIG_FILE, "cmd_pop" +  ((Integer)temp).toString(), cmd_pop[temp]);
						
						if(temp == ZDY_NUM-1) {
							temp = 0;
						} else temp++;
						txtIndex.setText(((Integer)temp).toString());
						edtZDLName.setText(cmd_name[temp]);
						edtZDYPush.setText(cmd_push[temp]);
						edtZDYPop.setText(cmd_pop[temp]);
		            default:
		                break;
		            }
		            return false;
				}
			});
			
			btnZDYOk.setOnTouchListener(new OnTouchListener() {
				
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()) {
		            case MotionEvent.ACTION_DOWN:// 按下
		            	btnZDYOk.setBackgroundResource(R.color.backgroud);
		                break;
		            case MotionEvent.ACTION_UP:  // // 松开
		            	btnZDYOk.setBackgroundResource(R.drawable.cb5_on);
						temp = Integer.parseInt(txtIndex.getText().toString());	
						cmd_name[temp] = edtZDLName.getText().toString();
						cmd_push[temp] = edtZDYPush.getText().toString();
						cmd_pop[temp] = edtZDYPop.getText().toString();
						if(temp<ZDY_NUM-6)btnDZ[temp].setText(cmd_name[temp]);
						
						if(temp<10)write_file(CONFIG_FILE, "cmd_name" +  ((Integer)temp).toString(), cmd_name[temp]);
				    	write_file(CONFIG_FILE, "cmd_push" + ((Integer)temp).toString(), cmd_push[temp]);
				    	write_file(CONFIG_FILE, "cmd_pop" +  ((Integer)temp).toString(), cmd_pop[temp]);
				    	
				    	configDialog.cancel();
		            default:
		                break;
		            }
		            return false;
				}
			});		
	    }
	    
		@Override
		public void onClick(DialogInterface dialog, int which) {
			// TODO Auto-generated method stub
			
		}
	}
   
   
	
	
	
	
}




