/** Automatically generated file. DO NOT MODIFY */
package com.zltech.ty;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}